// api.js - Handles all API calls

async function registerUser(userData) {
    try {
        const response = await fetch('/api/register.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        return await response.json();
    } catch (error) {
        console.error('Registration error:', error);
        return { success: false, message: 'Registration failed' };
    }
}

async function loginUser(credentials) {
    try {
        const response = await fetch('/api/login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });
        return await response.json();
    } catch (error) {
        console.error('Login error:', error);
        return { success: false, message: 'Login failed' };
    }
}

async function getProducts() {
    try {
        const response = await fetch('/api/products.php');
        const data = await response.json();
        return data.success ? data.products : [];
    } catch (error) {
        console.error('Error fetching products:', error);
        return [];
    }
}

async function addProduct(productData) {
    try {
        const response = await fetch('/api/products.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productData)
        });
        return await response.json();
    } catch (error) {
        console.error('Error adding product:', error);
        return { success: false, message: 'Failed to add product' };
    }
}