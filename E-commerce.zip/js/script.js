// script.js — product storage, rendering, search/filter, add product, delete product

const STORAGE_KEY = 'campus_bazar_products';

/**
 * Seed some demo products on first load
 */
function seedProducts() {
  const demo = [
    {
      id: genId(),
      name: "Discrete Math Book",
      category: "Books",
      desc: "Used but well kept, 2nd year materials.",
      price: 250,
      seller: "Ravi",
      contact: "ravi@student.edu",
      image: "https://picsum.photos/seed/book1/400/300"
    },
    {
      id: genId(),
      name: "Used Laptop Charger",
      category: "Electronics",
      desc: "Compatible with many models, working fine.",
      price: 600,
      seller: "Neha",
      contact: "neha@student.edu",
      image: "https://picsum.photos/seed/charger/400/300"
    },
    {
      id: genId(),
      name: "Hostel Bed Lamp",
      category: "Other",
      desc: "Adjustable lamp, USB powered.",
      price: 150,
      seller: "Aman",
      contact: "aman@student.edu",
      image: "https://picsum.photos/seed/lamp/400/300"
    },
    {
      id: genId(),
      name: "Study Table",
      category: "Furniture",
      desc: "Wooden, foldable, lightweight.",
      price: 1500,
      seller: "Priya",
      contact: "priya@student.edu",
      image: "https://picsum.photos/seed/table/400/300"
    }
  ];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(demo));
  return demo;
}

function genId() {
  return 'p_' + Math.random().toString(36).slice(2,9);
}

function getProducts() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return seedProducts();
  try {
    return JSON.parse(raw) || [];
  } catch (e) {
    return seedProducts();
  }
}

function saveProducts(arr) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

/**
 * Render products into a grid container (Bootstrap row)
 */
function renderProductsToGrid(products, containerId, enableDelete = false) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';

  if (!products || products.length === 0) {
    container.innerHTML = '';
    return;
  }

  products.forEach(prod => {
    const col = document.createElement('div');
    col.className = 'col-sm-6 col-md-4 col-lg-3';
    col.innerHTML = `
      <div class="card h-100 product-card shadow-sm">
        <img src="${prod.image || 'https://picsum.photos/400/300'}" class="card-img-top" alt="${escapeHtml(prod.name)}">
        <div class="card-body d-flex flex-column">
          <h6 class="card-title mb-1">${escapeHtml(prod.name)}</h6>
          <div class="mb-2 text-muted small">${escapeHtml(prod.category)} • ₹${prod.price}</div>
          <p class="card-text small text-truncate">${escapeHtml(prod.desc)}</p>
          <div class="mt-auto d-flex justify-content-between align-items-center">
            <button class="btn btn-sm btn-outline-primary" onclick="openProductModal('${prod.id}')">View</button>
            ${enableDelete ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteProduct('${prod.id}')">Delete</button>` : `<small class="text-muted">Seller: ${escapeHtml(prod.seller)}</small>`}
          </div>
        </div>
      </div>
    `;
    container.appendChild(col);
  });
}

/**
 * Delete product by ID
 */
function deleteProduct(id) {
  if (!confirm('Are you sure you want to delete this product?')) return;
  let products = getProducts();
  products = products.filter(p => p.id !== id);
  saveProducts(products);
  initShopPage(true);
  alert('Product deleted successfully!');
}

/**
 * Render featured (first N) items into container on home
 */
function renderFeatured(containerId, limit=4) {
  const all = getProducts();
  const featured = all.slice(0, limit);
  renderProductsToGrid(featured, containerId);
}

/**
 * Initialize shop page: attach events, render all products
 */
function initShopPage(enableDelete = false) {
  const products = getProducts();
  const gridId = 'product-grid';
  renderProductsToGrid(products, gridId, enableDelete);
  toggleNoProducts(products.length === 0);

  const searchEl = document.getElementById('search-input');
  const categoryEl = document.getElementById('category-select');

  function applyFilters() {
    const q = (searchEl.value || '').toLowerCase().trim();
    const cat = categoryEl.value;
    const all = getProducts();
    const filtered = all.filter(p => {
      const matchesQ =
        p.name.toLowerCase().includes(q) ||
        p.desc.toLowerCase().includes(q) ||
        p.seller.toLowerCase().includes(q);
      const matchesCat = (cat === 'all') || (p.category === cat);
      return matchesQ && matchesCat;
    });
    renderProductsToGrid(filtered, gridId, enableDelete);
    toggleNoProducts(filtered.length === 0);
  }

  searchEl.addEventListener('input', applyFilters);
  categoryEl.addEventListener('change', applyFilters);
}

function toggleNoProducts(show) {
  const el = document.getElementById('no-products');
  if (!el) return;
  el.style.display = show ? 'block' : 'none';
}

/**
 * Sell page initialization: handle form submit
 */
function initSellPage() {
  const form = document.getElementById('sell-form');
  const alertDiv = document.getElementById('sell-alert');
  const clearBtn = document.getElementById('clear-storage');

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('prod-name').value.trim();
    const category = document.getElementById('prod-category').value;
    const desc = document.getElementById('prod-desc').value.trim();
    const price = Number(document.getElementById('prod-price').value);
    const seller = document.getElementById('seller-name').value.trim();
    const contact = document.getElementById('seller-contact').value.trim();
    let image = document.getElementById('prod-image').value.trim();
    if (!image) image = `https://picsum.photos/seed/${encodeURIComponent(name)}/400/300`;

    const newProd = {
      id: genId(),
      name, category, desc, price, seller, contact, image
    };

    const all = getProducts();
    all.unshift(newProd); // add to front
    saveProducts(all);

    alertDiv.innerHTML = `<div class="alert alert-success">Your product "${escapeHtml(name)}" has been posted. It will appear in the Shop.</div>`;
    form.reset();
  });

  clearBtn.addEventListener('click', function () {
    if (!confirm('Clear all product listings? This cannot be undone.')) return;
    localStorage.removeItem(STORAGE_KEY);
    alertDiv.innerHTML = `<div class="alert alert-warning">All listings cleared. Demo items will be restored on next load.</div>`;
  });
}

/**
 * Open modal with detailed product info
 */
function openProductModal(prodId) {
  const all = getProducts();
  const p = all.find(x => x.id === prodId);
  if (!p) return;
  const modalContent = document.getElementById('modal-content-js');
  modalContent.innerHTML = `
    <div class="modal-header">
      <h5 class="modal-title">${escapeHtml(p.name)}</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <img src="${p.image}" alt="${escapeHtml(p.name)}" class="img-fluid mb-3">
      <p><strong>Price:</strong> ₹${p.price}</p>
      <p><strong>Category:</strong> ${escapeHtml(p.category)}</p>
      <p>${escapeHtml(p.desc)}</p>
      <hr>
      <p><strong>Seller:</strong> ${escapeHtml(p.seller)}</p>
      <p><strong>Contact:</strong> ${escapeHtml(p.contact)}</p>
    </div>
    <div class="modal-footer">
      <a href="mailto:${encodeURIComponent(p.contact)}" class="btn btn-primary">Contact Seller</a>
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    </div>
  `;
  const modalEl = new bootstrap.Modal(document.getElementById('productModal'));
  modalEl.show();
}

/**
 * Small util: escape HTML
 */
function escapeHtml(unsafe) {
  if (!unsafe && unsafe !== 0) return '';
  return String(unsafe)
    .replaceAll('&', "&amp;")
    .replaceAll('<', "&lt;")
    .replaceAll('>', "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/**
 * Expose functions globally
 */
window.initShopPage = initShopPage;
window.initSellPage = initSellPage;
window.openProductModal = openProductModal;
window.renderFeatured = renderFeatured;
window.deleteProduct = deleteProduct;
